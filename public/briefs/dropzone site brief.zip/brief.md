# dropzone

Site brief, handed in 2026-08-22.
Raised by chrxs_dev on 2026-08-22.

## The site

- **Name:** dropzone
- **Short name:** dropzone
- **Subdomain:** dropzone.ronation.live
- **Tagline:** Bass Without Borders
- **Ticket prefix:** DZUK
- **Roblox group:** https://www.roblox.com/communities/209336069/DROPZONE-RAVES#!/about
- **Features:** Shows, Blog, Careers, Surveys

### Description

Dropzone is a UK rave experience built around heavy bass, relentless energy and unforgettable nights. From DnB to techno and everything in between, we bring together the sounds, people and atmosphere that make rave culture what it is. No rules. No limits. Just pure energy.

### Disclaimer

> The partner supplied this themselves. Check it before it ships - a tribute or fan
> project on an RNL subdomain with an ambiguous disclaimer is RNL's problem too.

Tribute Acts

Some of the acts featured at DROPZONE are tribute acts celebrating the music of well-known artists and bands.

These performers are independent artists and are not the original artists, and are not affiliated with or endorsed by the artists, bands, or their management, estates, or record labels.

Artist and band names are used only to describe the tribute performance and the music being performed.

DROPZONE is an independent music event and entertainment brand.

## Look

- **Accent:** #080808
- **Type on accent:** #f8f8ff
- **Type direction:** Bold and condensed

### Notes

underground, dark, graffiti, dnb, strobing light

### References

- https://discord.gg/yyQXksymW
- https://www.roblox.com/communities/209336069/DROPZONE-RAVES#!/about

## Who to ask

- **Name:** reuben
- **Email:** dropzone997@gmail.com
- **Discord:** reuben01192

## Files

- `assets/backdrop-8ky0l1-Screenshot-2026-08-22-162649.png` - Backdrop, image/png, 605 KB
- `assets/crest-v2vji7-6af4d4b0-2ab8-42a6-a3a5-f63cb1ccdc0b.png` - Emblem, image/png, 2255 KB
- `assets/logo-1ffml3-ChatGPT-Image-Aug-22--2026--04_32_18-PM.png` - Wordmark, image/png, 986 KB
