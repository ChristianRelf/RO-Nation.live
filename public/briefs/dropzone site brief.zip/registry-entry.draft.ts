// A DRAFT. Nothing reads this file - it is here so that adding the partner site is
// reading and editing rather than transcribing.
//
// Before it goes in lib/partners/registry.ts:
//
//   1. Place the files from assets/ and replace every TODO path.
//   2. Check the slug is still free - slugVerdict() was true when they typed it,
//      not necessarily today.
//   3. Add the host to the Caddyfile's site address line, AFTER its DNS record
//      resolves. Caddy asks Let's Encrypt on reload and a failed issuance counts
//      against the weekly limit.
//   4. Leave `active: false` until the site is worth showing. An active slug with
//      no host in the Caddyfile is unreachable; a host with no registry entry
//      serves RNL's site on the partner's domain.
//   5. Write the brand stylesheet (src/styles/brands/) from the colours below.

// accent: #080808   ink on accent: #f8f8ff
// type: Bold and condensed

  {
    slug: "dropzone",
    name: "dropzone",
    shortName: "dropzone",
    tagline: "Bass Without Borders",
    description: "Dropzone is a UK rave experience built around heavy bass, relentless energy and unforgettable nights. From DnB to techno and everything in between, we bring together the sounds, people and atmosphere that make rave culture what it is. No rules. No limits. Just pure energy.",
    disclaimer: "Tribute Acts

Some of the acts featured at DROPZONE are tribute acts celebrating the music of well-known artists and bands.

These performers are independent artists and are not the original artists, and are not affiliated with or endorsed by the artists, bands, or their management, estates, or record labels.

Artist and band names are used only to describe the tribute performance and the music being performed.

DROPZONE is an independent music event and entertainment brand.",
    ticketPrefix: "DZUK",
    logoUrl: "TODO: place assets/logo-1ffml3-ChatGPT-Image-Aug-22--2026--04_32_18-PM.png",
    crestUrl: "TODO: place assets/crest-v2vji7-6af4d4b0-2ab8-42a6-a3a5-f63cb1ccdc0b.png",
    backdropUrl: "TODO: place assets/backdrop-8ky0l1-Screenshot-2026-08-22-162649.png",
    features: ["events", "blog", "careers", "surveys"] as const,
    robloxGroupUrl: "https://www.roblox.com/communities/209336069/DROPZONE-RAVES#!/about",
    active: false,
  },
